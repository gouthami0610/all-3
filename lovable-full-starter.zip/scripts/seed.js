/**
 * Seed script for Supabase (requires SUPABASE_SERVICE_ROLE_KEY env var)
 * This script inserts sample profiles, jobs and applications using the service role key.
 * Run: SUPABASE_SERVICE_ROLE_KEY=... node scripts/seed.js
 */
const { createClient } = require('@supabase/supabase-js')
const url = process.env.NEXT_PUBLIC_SUPABASE_URL
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
if (!url || !serviceKey) {
  console.error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in env before running.')
  process.exit(1)
}
const supabase = createClient(url, serviceKey)

async function run() {
  // NOTE: auth.users can't be created via API easily here; instead, create sample profiles with random UUIDs.
  const { data: p1 } = await supabase.from('profiles').insert([
    { id: '11111111-1111-1111-1111-111111111111', full_name: 'Asha Student', role: 'student', headline: 'Frontend developer' }
  ]).select().limit(1)
  const { data: p2 } = await supabase.from('profiles').insert([
    { id: '22222222-2222-2222-2222-222222222222', full_name: 'Ravi Employer', role: 'employer', headline: 'Hiring manager' }
  ]).select().limit(1)

  const { data: job } = await supabase.from('jobs').insert([
    { employer_id: '22222222-2222-2222-2222-222222222222', title: 'Frontend Engineer', description: 'React + TypeScript role', requirements: 'React, TS', location: 'Remote' }
  ]).select().limit(1)

  const { data: app } = await supabase.from('applications').insert([
    { job_id: job[0].id, student_id: '11111111-1111-1111-1111-111111111111', resume_url: 'https://example.com/resume.pdf' }
  ]).select().limit(1)

  console.log('Seed complete.')
  process.exit(0)
}

run().catch(e=>{console.error(e); process.exit(1)})
