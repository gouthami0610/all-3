'use client'
import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function ResumeUpload() {
  const [fileText, setFileText] = useState<string>('')
  const [result, setResult] = useState<any>(null)
  const [uploadMsg, setUploadMsg] = useState('')

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    const text = await f.text()
    setFileText(text)
  }

  async function analyze() {
    const res = await fetch('/api/ai/resume', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: fileText })
    })
    const data = await res.json()
    setResult(data)
  }

  async function uploadToStorage(e:any) {
    const f = e.target.files?.[0]
    if (!f) return
    setUploadMsg('Uploading...')
    const { data, error } = await supabase.storage.from(process.env.NEXT_PUBLIC_SUPABASE_BUCKET || 'resumes').upload(`public/${f.name}`, f)
    if (error) setUploadMsg('Error: ' + error.message)
    else setUploadMsg('Uploaded: ' + data.path)
  }

  return (
    <div className="p-4">
      <label className="block">Upload resume (txt/pdf conversion recommended)</label>
      <input type="file" accept=".txt,.md,.pdf,.docx" onChange={handleFile} />
      <div className="mt-2">
        <button onClick={analyze} className="px-4 py-2 rounded bg-gray-800 text-white">Analyze</button>
      </div>
      <div className="mt-4">
        <input type="file" onChange={uploadToStorage} />
        <p className="text-sm mt-2">{uploadMsg}</p>
      </div>

      {result && (
        <pre className="whitespace-pre-wrap mt-4 bg-gray-100 p-4 rounded">{JSON.stringify(result, null, 2)}</pre>
      )}
    </div>
  )
}
