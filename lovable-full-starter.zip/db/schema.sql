-- Supabase suggested tables (profiles linked to auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text,
  role text CHECK (role IN ('student','employer')) DEFAULT 'student',
  headline text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employer_id uuid REFERENCES profiles(id),
  title text NOT NULL,
  description text,
  requirements text,
  location text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id),
  student_id uuid REFERENCES profiles(id),
  resume_url text,
  status text CHECK (status IN ('applied','reviewing','interview','rejected','hired')) DEFAULT 'applied',
  created_at timestamptz DEFAULT now()
);
