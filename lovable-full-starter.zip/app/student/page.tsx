import ResumeUpload from '../components/ResumeUpload'

export default function StudentPage() {
  return (
    <main className="container mx-auto p-8">
      <h1 className="text-2xl font-bold">Student Dashboard</h1>
      <p className="mt-2">Manage your profile, upload resumes, and see applications.</p>
      <div className="mt-6">
        <ResumeUpload />
      </div>
    </main>
  )
}
