import Link from 'next/link'

export default function DashboardPage() {
  return (
    <main className="container mx-auto p-8">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="mt-4 space-x-4">
        <Link href="/student">Student area</Link>
        <Link href="/employer">Employer area</Link>
        <Link href="/ (auth)/login">Login</Link>
      </div>
    </main>
  )
}
