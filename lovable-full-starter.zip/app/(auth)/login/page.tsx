'use client'
import { useState } from 'react'
import { supabase } from '../../../lib/supabaseClient'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')

  async function signInPassword() {
    setMsg('Signing in...')
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) setMsg('Error: ' + error.message)
    else setMsg('Signed in. Welcome!')
  }

  async function signInGoogle() {
    await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } })
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-xl font-bold">Sign in</h2>
      <input className="block w-full my-2 p-2 border" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="block w-full my-2 p-2 border" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={signInPassword} className="px-4 py-2 bg-blue-600 text-white rounded">Sign in</button>
      <button onClick={signInGoogle} className="ml-2 px-4 py-2 border rounded">Sign in with Google</button>
      <p className="mt-4 text-sm">{msg}</p>
    </div>
  )
}
