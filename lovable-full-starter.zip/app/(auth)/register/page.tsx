'use client'
import { useState } from 'react'
import { supabase } from '../../../lib/supabaseClient'

export default function RegisterPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')

  async function register() {
    setMsg('Creating account...')
    const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } })
    if (error) setMsg('Error: ' + error.message)
    else setMsg('Check your email for confirmation link.')
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h2 className="text-xl font-bold">Register</h2>
      <input className="block w-full my-2 p-2 border" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="block w-full my-2 p-2 border" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={register} className="px-4 py-2 bg-green-600 text-white rounded">Create account</button>
      <p className="mt-4 text-sm">{msg}</p>
    </div>
  )
}
