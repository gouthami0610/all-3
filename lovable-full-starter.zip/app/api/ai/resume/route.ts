import { NextResponse } from 'next/server'
import { analyzeResume } from '../../../../lib/azureOpenAI'

export async function POST(request: Request) {
  try {
    const { text } = await request.json()
    if (!text) return NextResponse.json({ error: 'No resume text provided' }, { status: 400 })

    const prompt = `Analyze the following resume and output: 1) summary, 2) top skills, 3) suggested job titles, 4) ATS score (0-100), 5) improvement suggestions. Provide JSON only.\nRESUME:\n${text}`

    const result = await analyzeResume(prompt)

    const content = result?.choices?.[0]?.message?.content ?? JSON.stringify(result)
    try {
      const parsed = JSON.parse(content)
      return NextResponse.json({ parsed })
    } catch (e) {
      return NextResponse.json({ raw: content })
    }
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 })
  }
}
