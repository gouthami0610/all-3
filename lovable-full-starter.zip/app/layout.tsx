import './globals.css'
import { ReactNode } from 'react'

export const metadata = { title: 'Lovable', description: 'Career platform' }

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-slate-900">{children}</body>
    </html>
  )
}
