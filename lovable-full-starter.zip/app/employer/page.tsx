export default function EmployerPage() {
  return (
    <main className="container mx-auto p-8">
      <h1 className="text-2xl font-bold">Employer Dashboard</h1>
      <p className="mt-2">Post jobs and review candidates (sample UI).</p>
    </main>
  )
}
