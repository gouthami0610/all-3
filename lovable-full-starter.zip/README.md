# Lovable — Full Starter Project

This is the Full Starter Project for the Lovable app — Next.js (App Router) + Supabase + Azure OpenAI.

Features:
- Supabase Auth (Email+Password + Google OAuth)
- Student & Employer dashboards
- Resume upload + Azure OpenAI analysis
- Seed script to populate example profiles, jobs, and applications

## Quick start

1. Copy `.env.example` -> `.env.local` and fill secrets.
2. Configure Google OAuth provider in your Supabase project's Auth > Settings > External OAuth providers.
3. `npm install`
4. `npm run seed` (requires SUPABASE_SERVICE_ROLE_KEY in env)
5. `npm run dev`

