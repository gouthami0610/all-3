import axios from 'axios'

const endpoint = process.env.AZURE_OPENAI_ENDPOINT!
const key = process.env.AZURE_OPENAI_KEY!
const deployment = process.env.AZURE_OPENAI_DEPLOYMENT || 'gpt-5-nano-2025-08-07'
const apiVersion = process.env.AZURE_OPENAI_API_VERSION || '2024-08-01-preview'

export async function analyzeResume(prompt: string) {
  const url = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`
  const body = {
    messages: [
      { role: 'system', content: 'You are a helpful career assistant.' },
      { role: 'user', content: prompt }
    ],
    max_tokens: 800
  }
  const res = await axios.post(url, body, {
    headers: {
      'Content-Type': 'application/json',
      'api-key': key
    }
  })
  return res.data
}
