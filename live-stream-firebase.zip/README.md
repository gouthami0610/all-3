Live stream prototype (Firebase + WebRTC + Socket.IO)
---------------------------------------------------
Structure:
  - client/: Vite React app (uses Firebase for auth/storage — replace firebase.js config)
  - server/: Node + Socket.IO signalling server

Quick start:

1) Server:
  cd server
  npm install
  npm start
  (server listens on http://localhost:4000)

2) Client:
  cd client
  npm install
  # put your Firebase config into src/firebase.js
  npm run dev
  (open the printed Vite URL, e.g. http://localhost:5173)

Notes:
- This is a minimal prototype. For production you should add:
  * Firebase security rules
  * Proper authentication checks on signalling server
  * SSL/WSS (use HTTPS + secure websockets)
  * An SFU or managed provider for scaling to many viewers
