import React from 'react'
import { Link } from 'react-router-dom'

export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>Live Stream Firebase Demo</h1>
      <div style={{marginTop:10}}>
        <Link to="/login">Login</Link> | <Link to="/register">Register</Link> | <Link to="/dashboard">Dashboard</Link>
      </div>
    </div>
  )
}
