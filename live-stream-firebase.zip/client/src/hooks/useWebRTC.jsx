import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';

export default function useWebRTC({ serverUrl, roomId, role, onRemoteStream }) {
  const pcRef = useRef(null);
  const socketRef = useRef(null);
  const localStreamRef = useRef(null);

  useEffect(() => {
    const start = async () => {
      socketRef.current = io(serverUrl);
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      });
      pcRef.current = pc;

      pc.ontrack = (event) => {
        onRemoteStream && onRemoteStream(event.streams[0]);
      };

      pc.onicecandidate = (e) => {
        if (e.candidate) {
          socketRef.current.emit('signal', { to: roomId, data: { type: 'ice', candidate: e.candidate }});
        }
      };

      socketRef.current.on('connect', () => {
        socketRef.current.emit('join-room', { roomId, role });
      });

      socketRef.current.on('signal', async ({ from, data }) => {
        if (data.type === 'offer' && role === 'viewer') {
          await pc.setRemoteDescription(new RTCSessionDescription(data));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          socketRef.current.emit('signal', { to: from, data: pc.localDescription });
        } else if (data.type === 'answer' && role === 'host') {
          await pc.setRemoteDescription(new RTCSessionDescription(data));
        } else if (data.type === 'ice') {
          try { await pc.addIceCandidate(data.candidate); } catch (e) { console.warn(e); }
        }
      });

      if (role === 'host') {
        const localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        localStreamRef.current = localStream;
        localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
      }

      socketRef.current.on('peer-joined', async ({ peerId, role: peerRole }) => {
        if (role === 'host' && peerRole === 'viewer') {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          socketRef.current.emit('signal', { to: peerId, data: pc.localDescription });
        }
      });
    };

    start();

    return () => {
      pcRef.current && pcRef.current.close();
      socketRef.current && socketRef.current.disconnect();
    };
  }, [serverUrl, roomId, role, onRemoteStream]);

  return {
    getLocalStream: () => localStreamRef.current
  };
}
