import React, {useRef, useEffect, useState} from 'react'
import useWebRTC from '../hooks/useWebRTC'
import { useParams } from 'react-router-dom'

export default function LiveStream(){
  const { roomId } = useParams();
  const [role, setRole] = useState('host'); // allow user to choose
  const localRef = useRef(null);
  const remoteRef = useRef(null);

  const onRemoteStream = (stream) => {
    if (remoteRef.current) remoteRef.current.srcObject = stream;
  };

  const { getLocalStream } = useWebRTC({
    serverUrl: 'http://localhost:4000',
    roomId: roomId || 'demo-room',
    role,
    onRemoteStream
  });

  useEffect(() => {
    if (role === 'host') {
      const s = getLocalStream();
      if (s && localRef.current) localRef.current.srcObject = s;
    }
  }, [getLocalStream, role]);

  return (
    <div style={{padding:20}}>
      <h2>Live Stream: {roomId}</h2>
      <div>
        <label>
          <input type="radio" checked={role==='host'} onChange={()=>setRole('host')} /> Host
        </label>
        <label style={{marginLeft:10}}>
          <input type="radio" checked={role==='viewer'} onChange={()=>setRole('viewer')} /> Viewer
        </label>
      </div>

      {role==='host' && <div>
        <h3>Local (preview)</h3>
        <video ref={localRef} autoPlay muted playsInline style={{width:'80%'}} />
      </div>}

      <div>
        <h3>Remote</h3>
        <video ref={remoteRef} autoPlay playsInline style={{width:'80%'}} />
      </div>
    </div>
  )
}
