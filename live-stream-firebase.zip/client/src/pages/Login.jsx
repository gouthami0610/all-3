import React, {useState} from 'react'
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';

export default function Login(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const nav = useNavigate();

  const handle = async (e) => {
    e.preventDefault();
    try{
      await signInWithEmailAndPassword(auth, email, password);
      nav('/dashboard');
    }catch(err){
      alert(err.message);
    }
  };

  return (
    <div style={{padding:20}}>
      <h2>Login</h2>
      <form onSubmit={handle}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" /><br/>
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" /><br/>
        <button type="submit">Login</button>
      </form>
    </div>
  )
}
