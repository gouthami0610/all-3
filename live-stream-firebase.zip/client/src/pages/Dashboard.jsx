import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom';

export default function Dashboard(){
  const [roomId, setRoomId] = useState('');
  const nav = useNavigate();

  const start = () => {
    const id = roomId || Math.random().toString(36).slice(2,9);
    nav('/live/'+id);
  };

  return (
    <div style={{padding:20}}>
      <h2>Dashboard</h2>
      <input placeholder="room id (optional)" value={roomId} onChange={e=>setRoomId(e.target.value)} />
      <button onClick={start}>Start / Join</button>
    </div>
  )
}
