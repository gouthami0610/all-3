"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sparkles, ArrowRight, Plane, Utensils, Car, Film, ShoppingBag, Zap, Shield, Globe } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background Effects */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-3xl animate-float"
          style={{ animationDelay: "2s" }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent" />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="flex flex-col items-center text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-8 animate-pulse-glow">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Multi-Agent System</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight mb-6 text-balance">
            Your Smart
            <span className="block bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-gradient">
              Companion
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mb-10 text-pretty">
            One intelligent assistant, five specialized agents. From travel planning to price comparisons, experience
            the future of AI-powered assistance.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-16">
            <Link href="/chat">
              <Button size="lg" className="gap-2 text-base px-8 h-12">
                <Sparkles className="h-5 w-5" />
                Start Chatting
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="#agents">
              <Button size="lg" variant="outline" className="text-base px-8 h-12 bg-transparent">
                Explore Agents
              </Button>
            </Link>
          </div>

          {/* Agent Icons Row */}
          <div className="flex items-center gap-3 mb-12">
            {[
              { icon: Plane, color: "text-blue-400", bg: "bg-blue-500/10" },
              { icon: Utensils, color: "text-orange-400", bg: "bg-orange-500/10" },
              { icon: Car, color: "text-emerald-400", bg: "bg-emerald-500/10" },
              { icon: Film, color: "text-pink-400", bg: "bg-pink-500/10" },
              { icon: ShoppingBag, color: "text-purple-400", bg: "bg-purple-500/10" },
            ].map((item, idx) => {
              const Icon = item.icon
              return (
                <div
                  key={idx}
                  className={`flex h-12 w-12 items-center justify-center rounded-xl ${item.bg} transition-transform hover:scale-110`}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <Icon className={`h-6 w-6 ${item.color}`} />
                </div>
              )
            })}
          </div>

          {/* Stats/Features */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl">
            {[
              { icon: Zap, label: "Instant Responses", desc: "Real-time AI processing" },
              { icon: Shield, label: "Secure & Private", desc: "Your data stays safe" },
              { icon: Globe, label: "Always Available", desc: "24/7 intelligent assistance" },
            ].map((item, idx) => {
              const Icon = item.icon
              return (
                <div key={idx} className="flex flex-col items-center p-4 rounded-xl glass-card">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <span className="font-medium mb-1">{item.label}</span>
                  <span className="text-sm text-muted-foreground">{item.desc}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
