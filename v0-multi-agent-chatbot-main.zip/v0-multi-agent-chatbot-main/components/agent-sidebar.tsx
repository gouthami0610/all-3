"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { agents, type AgentType } from "@/lib/agents"
import { Badge } from "@/components/ui/badge"
import { Bot, Sparkles, Home } from "lucide-react"
import { Button } from "@/components/ui/button"

interface AgentSidebarProps {
  activeAgent: AgentType | null
  onSelectAgent: (agent: AgentType | null) => void
}

export function AgentSidebar({ activeAgent, onSelectAgent }: AgentSidebarProps) {
  return (
    <aside className="hidden lg:flex w-72 flex-col border-r border-border bg-sidebar">
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Bot className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="font-semibold text-foreground">SmartCompanion</h1>
            <p className="text-xs text-muted-foreground">Multi-Agent Orchestrator</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <Link href="/" className="block mb-4">
          <Button variant="outline" size="sm" className="w-full gap-2 justify-start bg-transparent">
            <Home className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <div className="mb-4">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Available Agents
          </h2>
          <div className="space-y-2">
            {agents.map((agent) => {
              const Icon = agent.icon
              const isActive = activeAgent === agent.id
              return (
                <button
                  key={agent.id}
                  onClick={() => onSelectAgent(isActive ? null : agent.id)}
                  className={cn(
                    "w-full flex items-start gap-3 p-3 rounded-lg transition-all text-left",
                    "hover:bg-secondary/50",
                    isActive && "bg-secondary",
                  )}
                >
                  <div className={cn("p-2 rounded-md", agent.bgColor)}>
                    <Icon className={cn("h-4 w-4", agent.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm text-foreground truncate">{agent.name}</span>
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[10px] px-1.5 py-0",
                          agent.status === "active"
                            ? "border-emerald-500/50 text-emerald-400"
                            : "border-muted-foreground/50 text-muted-foreground",
                        )}
                      >
                        {agent.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{agent.description}</p>
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        <div className="mt-6">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Quick Commands</h2>
          <div className="space-y-2 text-xs text-muted-foreground">
            <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
              <Sparkles className="h-3 w-3 text-primary" />
              <span>{'"Plan a trip to Paris"'}</span>
            </div>
            <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
              <Sparkles className="h-3 w-3 text-primary" />
              <span>{'"Find Italian restaurants nearby"'}</span>
            </div>
            <div className="flex items-center gap-2 p-2 rounded bg-secondary/30">
              <Sparkles className="h-3 w-3 text-primary" />
              <span>{'"Book a cab to the airport"'}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-border">
        <div className="text-xs text-muted-foreground">
          <p className="font-medium text-foreground mb-1">How it works</p>
          <p>Just type your request naturally. The orchestrator will automatically route to the right agent.</p>
        </div>
      </div>
    </aside>
  )
}
