"use client"

import { Brain, Layers, MessageSquare, Zap, RefreshCw, Lock } from "lucide-react"

const features = [
  {
    icon: Brain,
    title: "Intelligent Routing",
    description:
      "Our AI orchestrator automatically understands your intent and routes requests to the most suitable specialized agent.",
  },
  {
    icon: Layers,
    title: "Multi-Agent Coordination",
    description: "Agents work together seamlessly. Book a movie, and we'll suggest nearby restaurants automatically.",
  },
  {
    icon: MessageSquare,
    title: "Natural Conversations",
    description:
      "Just type naturally. No commands to memorize, no complex syntax. Ask like you're talking to a friend.",
  },
  {
    icon: Zap,
    title: "Instant Results",
    description: "Get real-time responses with live data from multiple sources, all presented in easy-to-read formats.",
  },
  {
    icon: RefreshCw,
    title: "Continuous Learning",
    description:
      "Our agents improve with every interaction, providing increasingly personalized and accurate assistance.",
  },
  {
    icon: Lock,
    title: "Privacy First",
    description: "Your conversations and data are encrypted and never shared. We prioritize your privacy and security.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            Powerful Features,
            <span className="text-primary"> Simple Experience</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Built with cutting-edge AI technology to make your daily tasks effortless and enjoyable.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon
            return (
              <div
                key={idx}
                className="group p-6 rounded-2xl glass-card hover:bg-secondary/30 transition-all duration-300"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors mb-4">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
