"use client"

import { cn } from "@/lib/utils"
import { agents, type AgentType } from "@/lib/agents"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Bot, Menu } from "lucide-react"

interface MobileAgentDrawerProps {
  activeAgent: AgentType | null
  onSelectAgent: (agent: AgentType | null) => void
}

export function MobileAgentDrawer({ activeAgent, onSelectAgent }: MobileAgentDrawerProps) {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="lg:hidden">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-80 bg-sidebar p-0">
        <SheetHeader className="p-4 border-b border-border">
          <SheetTitle className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div className="text-left">
              <p className="font-semibold text-foreground">AI Agent Hub</p>
              <p className="text-xs text-muted-foreground font-normal">Multi-Agent Orchestrator</p>
            </div>
          </SheetTitle>
        </SheetHeader>

        <div className="p-4">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Available Agents
          </h2>
          <div className="space-y-2">
            {agents.map((agent) => {
              const Icon = agent.icon
              const isActive = activeAgent === agent.id
              return (
                <button
                  key={agent.id}
                  onClick={() => onSelectAgent(isActive ? null : agent.id)}
                  className={cn(
                    "w-full flex items-start gap-3 p-3 rounded-lg transition-all text-left",
                    "hover:bg-secondary/50",
                    isActive && "bg-secondary",
                  )}
                >
                  <div className={cn("p-2 rounded-md", agent.bgColor)}>
                    <Icon className={cn("h-4 w-4", agent.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm text-foreground truncate">{agent.name}</span>
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[10px] px-1.5 py-0",
                          agent.status === "active"
                            ? "border-emerald-500/50 text-emerald-400"
                            : "border-muted-foreground/50 text-muted-foreground",
                        )}
                      >
                        {agent.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{agent.description}</p>
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
