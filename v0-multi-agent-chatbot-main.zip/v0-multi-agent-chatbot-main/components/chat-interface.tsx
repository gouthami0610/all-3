"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { cn } from "@/lib/utils"
import { agents, detectAgent, type AgentType } from "@/lib/agents"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Send,
  Bot,
  User,
  Loader2,
  Plane,
  Utensils,
  Car,
  Film,
  ShoppingBag,
  MapPin,
  Clock,
  DollarSign,
  Star,
  Ticket,
  Package,
  AlertTriangle,
} from "lucide-react"

interface ChatInterfaceProps {
  activeAgent: AgentType | null
}

const demoResponses: Record<AgentType, { text: string; toolResult: Record<string, unknown> }> = {
  travel: {
    text: "I found some great travel options for you! Here are the most optimal routes I discovered:",
    toolResult: {
      agent: "travel",
      routes: [
        { type: "Flight", duration: "2h 30m", price: "$299", details: "Direct flight with premium amenities" },
        { type: "Train", duration: "5h 15m", price: "$89", details: "Express train with scenic views" },
        { type: "Bus", duration: "8h", price: "$45", details: "Overnight bus with WiFi and comfort" },
      ],
      recommendation: "Flight recommended for best time-to-cost ratio",
      date: "Flexible dates available",
    },
  },
  food: {
    text: "Here are the best restaurants I found near your location:",
    toolResult: {
      agent: "food",
      restaurants: [
        {
          name: "The Golden Fork",
          cuisine: "Italian",
          rating: 4.8,
          priceRange: "$$",
          distance: "0.5 km",
          speciality: "Handmade pasta",
        },
        {
          name: "Spice Garden",
          cuisine: "Indian",
          rating: 4.6,
          priceRange: "$$",
          distance: "1.2 km",
          speciality: "Authentic curries",
        },
        {
          name: "Sakura House",
          cuisine: "Japanese",
          rating: 4.7,
          priceRange: "$$$",
          distance: "0.8 km",
          speciality: "Fresh sushi",
        },
      ],
      location: "your area",
    },
  },
  cab: {
    text: "Your cab has been booked! Here are the details:",
    toolResult: {
      agent: "cab",
      booking: {
        status: "Confirmed",
        bookingId: "CAB" + Date.now().toString().slice(-6),
        pickup: "Current Location",
        dropoff: "Destination",
        rideType: "Premium",
        estimatedArrival: "5 mins",
        estimatedFare: "$18-25",
        driver: { name: "Alex M.", rating: 4.9, vehicle: "Tesla Model 3 - White", plate: "EV 2024" },
      },
    },
  },
  movie: {
    text: "Your movie tickets are booked! Here's your confirmation:",
    toolResult: {
      agent: "movie",
      booking: {
        status: "Confirmed",
        bookingId: "MOV" + Date.now().toString().slice(-6),
        movie: "Your Selected Movie",
        theater: "Cineplex Downtown IMAX",
        showtime: "7:00 PM",
        seats: 2,
        seatNumbers: ["G12", "G13"],
        totalPrice: "$29.98",
        screen: "Screen 4 - IMAX 3D",
      },
    },
  },
  shopping: {
    text: "I've compared prices across multiple retailers for you:",
    toolResult: {
      agent: "shopping",
      product: "Your Product",
      category: "Electronics",
      comparisons: [
        { store: "Amazon", price: "$299.99", shipping: "Free", delivery: "2 days", rating: 4.5 },
        { store: "Best Buy", price: "$289.99", shipping: "$5.99", delivery: "3-5 days", rating: 4.3 },
        { store: "Walmart", price: "$279.99", shipping: "Free", delivery: "5-7 days", rating: 4.2 },
      ],
      bestDeal: "Walmart offers the lowest price with free shipping!",
    },
  },
}

// Demo message type
interface DemoMessage {
  id: string
  role: "user" | "assistant"
  content: string
  agent?: AgentType
  toolResult?: Record<string, unknown>
}

export function ChatInterface({ activeAgent }: ChatInterfaceProps) {
  const [input, setInput] = useState("")
  const [demoMode, setDemoMode] = useState(false)
  const [demoMessages, setDemoMessages] = useState<DemoMessage[]>([])
  const [isTyping, setIsTyping] = useState(false)
  const [apiError, setApiError] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, sendMessage, status, error } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
    onError: (err) => {
      console.log("[v0] Chat error:", err.message)
      if (err.message.includes("credit card") || err.message.includes("AI Gateway")) {
        setDemoMode(true)
        setApiError("AI Gateway requires setup. Running in demo mode.")
      }
    },
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, demoMessages])

  const handleDemoSubmit = async (messageText: string) => {
    const userMessage: DemoMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: messageText,
    }
    setDemoMessages((prev) => [...prev, userMessage])
    setIsTyping(true)

    // Detect which agent should respond
    const detectedAgent = detectAgent(messageText)
    const agentToUse = detectedAgent || "travel"

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const response = demoResponses[agentToUse]
    const assistantMessage: DemoMessage = {
      id: `assistant-${Date.now()}`,
      role: "assistant",
      content: response.text,
      agent: agentToUse,
      toolResult: response.toolResult,
    }

    setDemoMessages((prev) => [...prev, assistantMessage])
    setIsTyping(false)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return
    if (demoMode) {
      if (isTyping) return
      handleDemoSubmit(input)
      setInput("")
      return
    }
    if (status !== "ready") return

    const messageToSend = activeAgent ? `[Using ${agents.find((a) => a.id === activeAgent)?.name}] ${input}` : input

    sendMessage({ text: messageToSend })
    setInput("")
  }

  const renderToolResult = (part: { type?: string; output?: Record<string, unknown> } | Record<string, unknown>) => {
    const output = (part as { output?: Record<string, unknown> }).output || part
    if (!output) return null

    const agent = output.agent as string

    if (agent === "travel" && output.routes) {
      const routes = output.routes as Array<{ type: string; duration: string; price: string; details: string }>
      return (
        <Card className="p-4 bg-blue-500/10 border-blue-500/30 mt-2">
          <div className="flex items-center gap-2 mb-3">
            <Plane className="h-4 w-4 text-blue-400" />
            <span className="font-semibold text-blue-400">Travel Routes Found</span>
          </div>
          <div className="space-y-3">
            {routes.map((route, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-secondary/50 rounded">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="text-xs">
                    {route.type}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {route.duration}
                  </div>
                </div>
                <div className="flex items-center gap-1 text-sm font-medium text-emerald-400">
                  <DollarSign className="h-3 w-3" />
                  {route.price}
                </div>
              </div>
            ))}
          </div>
          {output.recommendation && (
            <p className="text-xs text-muted-foreground mt-3 italic">Tip: {output.recommendation as string}</p>
          )}
        </Card>
      )
    }

    if (agent === "food" && output.restaurants) {
      const restaurants = output.restaurants as Array<{
        name: string
        cuisine: string
        rating: number
        priceRange: string
        distance: string
        speciality: string
      }>
      return (
        <Card className="p-4 bg-orange-500/10 border-orange-500/30 mt-2">
          <div className="flex items-center gap-2 mb-3">
            <Utensils className="h-4 w-4 text-orange-400" />
            <span className="font-semibold text-orange-400">Restaurants Near {output.location as string}</span>
          </div>
          <div className="space-y-3">
            {restaurants.map((restaurant, idx) => (
              <div key={idx} className="p-3 bg-secondary/50 rounded">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">{restaurant.name}</span>
                  <div className="flex items-center gap-1 text-yellow-400">
                    <Star className="h-3 w-3 fill-current" />
                    <span className="text-xs">{restaurant.rating}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{restaurant.cuisine}</span>
                  <span>{restaurant.priceRange}</span>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {restaurant.distance}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Specialty: {restaurant.speciality}</p>
              </div>
            ))}
          </div>
        </Card>
      )
    }

    if (agent === "cab" && output.booking) {
      const booking = output.booking as {
        status: string
        bookingId: string
        pickup: string
        dropoff: string
        rideType: string
        estimatedArrival: string
        estimatedFare: string
        driver: { name: string; rating: number; vehicle: string; plate: string }
      }
      return (
        <Card className="p-4 bg-emerald-500/10 border-emerald-500/30 mt-2">
          <div className="flex items-center gap-2 mb-3">
            <Car className="h-4 w-4 text-emerald-400" />
            <span className="font-semibold text-emerald-400">Cab Booked!</span>
            <Badge className="bg-emerald-500 text-xs">{booking.status}</Badge>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Booking ID</span>
              <span className="font-mono">{booking.bookingId}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Pickup</span>
              <span>{booking.pickup}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Drop-off</span>
              <span>{booking.dropoff}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">ETA</span>
              <span className="text-emerald-400">{booking.estimatedArrival}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Fare</span>
              <span>{booking.estimatedFare}</span>
            </div>
            <div className="mt-3 p-2 bg-secondary/50 rounded">
              <p className="text-xs text-muted-foreground mb-1">Driver</p>
              <p className="font-medium">
                {booking.driver.name} - {booking.driver.rating} rating
              </p>
              <p className="text-xs text-muted-foreground">
                {booking.driver.vehicle} | {booking.driver.plate}
              </p>
            </div>
          </div>
        </Card>
      )
    }

    if (agent === "movie" && output.booking) {
      const booking = output.booking as {
        status: string
        bookingId: string
        movie: string
        theater: string
        showtime: string
        seats: number
        seatNumbers: string[]
        totalPrice: string
        screen: string
      }
      return (
        <Card className="p-4 bg-pink-500/10 border-pink-500/30 mt-2">
          <div className="flex items-center gap-2 mb-3">
            <Film className="h-4 w-4 text-pink-400" />
            <span className="font-semibold text-pink-400">Movie Tickets Booked!</span>
            <Badge className="bg-pink-500 text-xs">{booking.status}</Badge>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Movie</span>
              <span className="font-medium">{booking.movie}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Theater</span>
              <span>{booking.theater}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Showtime</span>
              <span>{booking.showtime}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Screen</span>
              <span>{booking.screen}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Seats</span>
              <span className="flex items-center gap-1">
                <Ticket className="h-3 w-3" />
                {booking.seatNumbers.join(", ")}
              </span>
            </div>
            <div className="flex justify-between font-medium">
              <span className="text-muted-foreground">Total</span>
              <span className="text-pink-400">{booking.totalPrice}</span>
            </div>
          </div>
        </Card>
      )
    }

    if (agent === "shopping" && output.comparisons) {
      const comparisons = output.comparisons as Array<{
        store: string
        price: string
        shipping: string
        delivery: string
        rating: number
      }>
      return (
        <Card className="p-4 bg-purple-500/10 border-purple-500/30 mt-2">
          <div className="flex items-center gap-2 mb-3">
            <ShoppingBag className="h-4 w-4 text-purple-400" />
            <span className="font-semibold text-purple-400">Price Comparison: {output.product as string}</span>
          </div>
          <div className="space-y-2">
            {comparisons.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-secondary/50 rounded">
                <div>
                  <span className="font-medium">{item.store}</span>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{item.shipping} shipping</span>
                    <span>|</span>
                    <span>{item.delivery}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-lg">{item.price}</span>
                  <div className="flex items-center gap-1 text-yellow-400 text-xs">
                    <Star className="h-3 w-3 fill-current" />
                    {item.rating}
                  </div>
                </div>
              </div>
            ))}
          </div>
          {output.bestDeal && (
            <p className="text-xs text-emerald-400 mt-3">
              <Package className="h-3 w-3 inline mr-1" />
              {output.bestDeal as string}
            </p>
          )}
        </Card>
      )
    }

    return null
  }

  // Determine which messages to render
  const displayMessages = demoMode ? demoMessages : messages

  return (
    <div className="flex flex-col h-full">
      {apiError && (
        <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/10 border-b border-amber-500/30 text-amber-400 text-sm">
          <AlertTriangle className="h-4 w-4" />
          <span>{apiError}</span>
          <span className="text-muted-foreground ml-2">Try the demo to see how the agents work!</span>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {displayMessages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 mb-4">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Welcome to AI Agent Hub</h2>
            <p className="text-muted-foreground max-w-md mb-6">
              I can help you with travel planning, finding restaurants, booking cabs, movie tickets, and shopping
              comparisons. Just tell me what you need!
            </p>
            {demoMode && (
              <Badge variant="outline" className="mb-4 border-amber-500/50 text-amber-400">
                Demo Mode Active
              </Badge>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-w-2xl">
              {[
                { icon: Plane, text: "Plan a trip to Tokyo", color: "text-blue-400" },
                { icon: Utensils, text: "Find Thai food near me", color: "text-orange-400" },
                { icon: Car, text: "Book a cab to airport", color: "text-emerald-400" },
                { icon: Film, text: "Book Dune 2 tickets", color: "text-pink-400" },
                { icon: ShoppingBag, text: "Compare iPhone prices", color: "text-purple-400" },
              ].map((item, idx) => {
                const Icon = item.icon
                return (
                  <button
                    key={idx}
                    onClick={() => setInput(item.text)}
                    className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors text-left"
                  >
                    <Icon className={cn("h-4 w-4", item.color)} />
                    <span className="text-sm">{item.text}</span>
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {demoMode &&
          demoMessages.map((message) => {
            const detectedAgent = message.role === "user" ? detectAgent(message.content) : null
            const agentInfo = detectedAgent ? agents.find((a) => a.id === detectedAgent) : null

            return (
              <div
                key={message.id}
                className={cn("flex gap-3", message.role === "user" ? "justify-end" : "justify-start")}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}

                <div
                  className={cn(
                    "max-w-[80%] rounded-lg p-3",
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary",
                  )}
                >
                  {message.role === "user" && agentInfo && (
                    <div className="flex items-center gap-1 mb-1 opacity-80">
                      <agentInfo.icon className="h-3 w-3" />
                      <span className="text-xs">{agentInfo.name}</span>
                    </div>
                  )}
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  {message.toolResult && renderToolResult(message.toolResult)}
                </div>

                {message.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
            )
          })}

        {/* Render real API messages */}
        {!demoMode &&
          messages.map((message) => {
            const detectedAgent =
              message.role === "user"
                ? detectAgent(message.parts.map((p) => (p.type === "text" ? p.text : "")).join(""))
                : null
            const agentInfo = detectedAgent ? agents.find((a) => a.id === detectedAgent) : null

            return (
              <div
                key={message.id}
                className={cn("flex gap-3", message.role === "user" ? "justify-end" : "justify-start")}
              >
                {message.role === "assistant" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Bot className="h-4 w-4 text-primary" />
                  </div>
                )}

                <div
                  className={cn(
                    "max-w-[80%] rounded-lg p-3",
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary",
                  )}
                >
                  {message.role === "user" && agentInfo && (
                    <div className="flex items-center gap-1 mb-1 opacity-80">
                      <agentInfo.icon className="h-3 w-3" />
                      <span className="text-xs">{agentInfo.name}</span>
                    </div>
                  )}
                  {message.parts.map((part, index) => {
                    if (part.type === "text") {
                      return (
                        <p key={index} className="text-sm whitespace-pre-wrap">
                          {part.text}
                        </p>
                      )
                    }
                    if (part.type.startsWith("tool-")) {
                      const toolPart = part as { type: string; state: string; output?: Record<string, unknown> }
                      if (toolPart.state === "output-available") {
                        return <div key={index}>{renderToolResult(toolPart)}</div>
                      }
                      if (toolPart.state === "input-available") {
                        return (
                          <div key={index} className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                            <Loader2 className="h-3 w-3 animate-spin" />
                            Processing request...
                          </div>
                        )
                      }
                    }
                    return null
                  })}
                </div>

                {message.role === "user" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
            )
          })}

        {/* Typing indicator */}
        {(status === "streaming" || isTyping) && (
          <div className="flex gap-3">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <Bot className="h-4 w-4 text-primary" />
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
                <span className="text-sm text-muted-foreground">Thinking...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-border p-4">
        {activeAgent && (
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="outline" className="text-xs">
              Using: {agents.find((a) => a.id === activeAgent)?.name}
            </Badge>
          </div>
        )}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              demoMode
                ? "Try: 'Find Thai restaurants nearby' or 'Book a cab to downtown'"
                : "Ask me anything about travel, food, cabs, movies, or shopping..."
            }
            className="flex-1 bg-secondary rounded-lg px-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            disabled={!demoMode && status !== "ready"}
          />
          <Button
            type="submit"
            size="icon"
            disabled={!input.trim() || (!demoMode && status !== "ready") || isTyping}
            className="h-12 w-12 rounded-lg"
          >
            {(status !== "ready" && !demoMode) || isTyping ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  )
}
