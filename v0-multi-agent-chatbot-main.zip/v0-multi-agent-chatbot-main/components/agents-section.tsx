"use client"

import { agents } from "@/lib/agents"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2 } from "lucide-react"

export function AgentsSection() {
  return (
    <section id="agents" className="py-24 lg:py-32 bg-secondary/20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            Meet Your
            <span className="text-primary"> AI Agents</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Five specialized agents, each an expert in their domain, working together to assist you.
          </p>
        </div>

        {/* Agents Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent, idx) => {
            const Icon = agent.icon
            return (
              <div
                key={agent.id}
                className={cn(
                  "group relative p-6 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all duration-300",
                  idx === 0 && "lg:col-span-2",
                )}
              >
                {/* Agent Icon & Status */}
                <div className="flex items-start justify-between mb-4">
                  <div className={cn("p-3 rounded-xl", agent.bgColor)}>
                    <Icon className={cn("h-6 w-6", agent.color)} />
                  </div>
                  <Badge variant="outline" className="border-emerald-500/50 text-emerald-400 text-xs">
                    Active
                  </Badge>
                </div>

                {/* Agent Info */}
                <h3 className="font-semibold text-lg mb-2">{agent.name}</h3>
                <p className="text-muted-foreground mb-4">{agent.description}</p>

                {/* Capabilities */}
                <div className="space-y-2">
                  {agent.capabilities.slice(0, 3).map((capability, capIdx) => (
                    <div key={capIdx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className={cn("h-4 w-4", agent.color)} />
                      <span>{capability}</span>
                    </div>
                  ))}
                </div>

                {/* Hover Effect */}
                <div
                  className={cn(
                    "absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none",
                    "bg-gradient-to-br from-transparent via-transparent to-primary/5",
                  )}
                />
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
