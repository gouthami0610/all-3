"use client"

import { MessageSquare, Cpu, Sparkles, CheckCircle } from "lucide-react"

const steps = [
  {
    icon: MessageSquare,
    title: "Ask Anything",
    description: "Type your request naturally. Whether it's planning a trip, finding food, or comparing prices.",
    example: '"Find me the best route to Tokyo and suggest restaurants there"',
  },
  {
    icon: Cpu,
    title: "AI Orchestration",
    description: "Our intelligent orchestrator analyzes your request and routes it to the right specialized agents.",
    example: "Travel + Food agents activated",
  },
  {
    icon: Sparkles,
    title: "Agent Processing",
    description: "Specialized agents process your request using real-time data from multiple sources.",
    example: "Fetching routes, comparing prices, finding restaurants...",
  },
  {
    icon: CheckCircle,
    title: "Get Results",
    description: "Receive comprehensive, actionable results in beautifully formatted cards.",
    example: "Complete trip plan with dining recommendations",
  },
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            How It
            <span className="text-primary"> Works</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From question to answer in seconds. Here's the magic behind your smart companion.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-24 left-[calc(12.5%+1.5rem)] right-[calc(12.5%+1.5rem)] h-0.5 bg-border" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, idx) => {
              const Icon = step.icon
              return (
                <div key={idx} className="relative flex flex-col items-center text-center">
                  {/* Step Number & Icon */}
                  <div className="relative mb-6">
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border-2 border-primary/20">
                      <Icon className="h-7 w-7 text-primary" />
                    </div>
                    <div className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                      {idx + 1}
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                  <p className="text-muted-foreground mb-4 text-sm leading-relaxed">{step.description}</p>

                  {/* Example */}
                  <div className="px-4 py-2 rounded-lg bg-secondary/50 border border-border/50">
                    <p className="text-xs text-muted-foreground italic">{step.example}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
