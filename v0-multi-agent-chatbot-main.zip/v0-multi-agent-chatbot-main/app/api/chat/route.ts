import { consumeStream, convertToModelMessages, streamText, tool, type UIMessage } from "ai"
import { z } from "zod"

export const maxDuration = 30

// Travel Agent Tools
const findTravelRoute = tool({
  description: "Find the most optimal travel route between two locations",
  inputSchema: z.object({
    origin: z.string().describe("Starting location"),
    destination: z.string().describe("Destination location"),
    travelDate: z.string().optional().describe("Date of travel"),
  }),
  execute: async ({ origin, destination, travelDate }) => {
    // Simulated response - in production, integrate with travel APIs
    return {
      agent: "travel",
      routes: [
        {
          type: "Flight",
          duration: "2h 30m",
          price: "$299",
          details: `Direct flight from ${origin} to ${destination}`,
        },
        {
          type: "Train",
          duration: "5h 15m",
          price: "$89",
          details: `Express train with one stop`,
        },
        {
          type: "Bus",
          duration: "8h",
          price: "$45",
          details: `Overnight bus with amenities`,
        },
      ],
      recommendation: "Flight is recommended for the best time-to-cost ratio",
      date: travelDate || "Flexible dates",
    }
  },
})

// Food Agent Tools
const findRestaurants = tool({
  description: "Find the best restaurants near a location",
  inputSchema: z.object({
    location: z.string().describe("Location to search near"),
    cuisine: z.string().optional().describe("Type of cuisine"),
    priceRange: z.string().optional().describe("Budget range"),
  }),
  execute: async ({ location, cuisine, priceRange }) => {
    return {
      agent: "food",
      restaurants: [
        {
          name: "The Golden Fork",
          cuisine: cuisine || "Italian",
          rating: 4.8,
          priceRange: priceRange || "$$",
          distance: "0.5 km",
          speciality: "Handmade pasta",
        },
        {
          name: "Spice Garden",
          cuisine: cuisine || "Indian",
          rating: 4.6,
          priceRange: priceRange || "$$",
          distance: "1.2 km",
          speciality: "Authentic curries",
        },
        {
          name: "Sakura House",
          cuisine: cuisine || "Japanese",
          rating: 4.7,
          priceRange: priceRange || "$$$",
          distance: "0.8 km",
          speciality: "Fresh sushi",
        },
      ],
      location,
    }
  },
})

// Cab Agent Tools
const bookCab = tool({
  description: "Book a cab from one location to another",
  inputSchema: z.object({
    pickup: z.string().describe("Pickup location"),
    dropoff: z.string().describe("Drop-off location"),
    rideType: z.string().optional().describe("Type of ride (economy, premium, etc.)"),
  }),
  execute: async ({ pickup, dropoff, rideType }) => {
    return {
      agent: "cab",
      booking: {
        status: "Confirmed",
        bookingId: `CAB${Date.now().toString().slice(-6)}`,
        pickup,
        dropoff,
        rideType: rideType || "Economy",
        estimatedArrival: "5 mins",
        estimatedFare: "$15-20",
        driver: {
          name: "John D.",
          rating: 4.9,
          vehicle: "Toyota Camry - White",
          plate: "ABC 1234",
        },
      },
    }
  },
})

// Movie Agent Tools
const bookMovie = tool({
  description: "Book movie tickets for a specific show",
  inputSchema: z.object({
    movie: z.string().describe("Name of the movie"),
    theater: z.string().optional().describe("Preferred theater"),
    showtime: z.string().optional().describe("Preferred showtime"),
    seats: z.number().optional().describe("Number of seats"),
  }),
  execute: async ({ movie, theater, showtime, seats }) => {
    return {
      agent: "movie",
      booking: {
        status: "Confirmed",
        bookingId: `MOV${Date.now().toString().slice(-6)}`,
        movie,
        theater: theater || "Cineplex Downtown",
        showtime: showtime || "7:00 PM",
        seats: seats || 2,
        seatNumbers: ["G12", "G13"],
        totalPrice: `$${(seats || 2) * 14.99}`,
        screen: "Screen 4 - IMAX",
      },
    }
  },
})

// Shopping Agent Tools
const compareShoppingPrices = tool({
  description: "Compare prices for a product across multiple websites",
  inputSchema: z.object({
    product: z.string().describe("Product to search for"),
    category: z.string().optional().describe("Product category"),
  }),
  execute: async ({ product, category }) => {
    return {
      agent: "shopping",
      product,
      category: category || "Electronics",
      comparisons: [
        {
          store: "Amazon",
          price: "$299.99",
          shipping: "Free",
          delivery: "2 days",
          rating: 4.5,
        },
        {
          store: "Best Buy",
          price: "$289.99",
          shipping: "$5.99",
          delivery: "3-5 days",
          rating: 4.3,
        },
        {
          store: "Walmart",
          price: "$279.99",
          shipping: "Free",
          delivery: "5-7 days",
          rating: 4.2,
        },
      ],
      bestDeal: "Walmart offers the lowest price with free shipping",
    }
  },
})

const systemPrompt = `You are an AI Agent Orchestrator that manages 5 specialized agents. Your job is to understand user requests and route them to the appropriate agent.

Available Agents:
1. **Travel Agent** - Finds optimal travel routes, compares flights, trains, buses. Use for any travel-related queries.
2. **Food Agent** - Discovers best restaurants nearby, checks ratings, filters by cuisine. Use for food and dining queries.
3. **Cab Agent** - Books rides, schedules pickups, compares ride options. Use for transportation/cab booking queries.
4. **Movie Agent** - Books tickets, checks showtimes, selects seats. Use for movie and cinema queries.
5. **Shopping Agent** - Compares prices across websites, finds deals. Use for shopping and product queries.

When a user asks something:
1. Identify which agent(s) should handle the request
2. Use the appropriate tool to fulfill the request
3. Present the results in a clear, helpful format
4. If the query spans multiple agents, coordinate between them

Always be helpful, concise, and proactive in suggesting related services. For example, if someone books a movie, you might mention the Food Agent for dinner recommendations nearby.`

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const result = streamText({
    model: "anthropic/claude-sonnet-4-20250514",
    system: systemPrompt,
    messages: convertToModelMessages(messages),
    tools: {
      findTravelRoute,
      findRestaurants,
      bookCab,
      bookMovie,
      compareShoppingPrices,
    },
    abortSignal: req.signal,
    stopWhen: (options) => options.stepCount >= 3,
  })

  return result.toUIMessageStreamResponse({
    consumeSseStream: consumeStream,
  })
}
