"use client"

import { useState } from "react"
import Link from "next/link"
import type { AgentType } from "@/lib/agents"
import { AgentSidebar } from "@/components/agent-sidebar"
import { ChatInterface } from "@/components/chat-interface"
import { MobileAgentDrawer } from "@/components/mobile-agent-drawer"
import { Bot, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ChatPage() {
  const [activeAgent, setActiveAgent] = useState<AgentType | null>(null)

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar - Desktop */}
      <AgentSidebar activeAgent={activeAgent} onSelectAgent={setActiveAgent} />

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            {/* Mobile Drawer */}
            <div className="lg:hidden">
              <MobileAgentDrawer activeAgent={activeAgent} onSelectAgent={setActiveAgent} />
            </div>

            {/* Back Button - Desktop */}
            <Link href="/" className="hidden lg:flex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <span className="font-semibold">AI Assistant</span>
          </div>

          {/* Back Button - Mobile */}
          <Link href="/" className="lg:hidden">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
        </header>

        {/* Chat Interface */}
        <ChatInterface activeAgent={activeAgent} />
      </main>
    </div>
  )
}
