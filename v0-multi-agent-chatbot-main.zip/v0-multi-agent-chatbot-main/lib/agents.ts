import { Plane, Utensils, Car, Film, ShoppingBag } from "lucide-react"

export type AgentType = "travel" | "food" | "cab" | "movie" | "shopping"

export interface Agent {
  id: AgentType
  name: string
  description: string
  icon: typeof Plane
  color: string
  bgColor: string
  status: "active" | "idle" | "processing"
  capabilities: string[]
}

export const agents: Agent[] = [
  {
    id: "travel",
    name: "Travel Agent",
    description: "Find optimal travel routes and plan trips",
    icon: Plane,
    color: "text-blue-400",
    bgColor: "bg-blue-500/10",
    status: "active",
    capabilities: ["Find optimal routes", "Compare flight prices", "Suggest itineraries", "Check travel advisories"],
  },
  {
    id: "food",
    name: "Food Agent",
    description: "Discover the best restaurants near you",
    icon: Utensils,
    color: "text-orange-400",
    bgColor: "bg-orange-500/10",
    status: "active",
    capabilities: ["Find nearby restaurants", "Check ratings & reviews", "Filter by cuisine", "Compare prices"],
  },
  {
    id: "cab",
    name: "Cab Agent",
    description: "Book rides from point A to B",
    icon: Car,
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
    status: "active",
    capabilities: ["Book instant rides", "Schedule pickups", "Compare ride options", "Track live location"],
  },
  {
    id: "movie",
    name: "Movie Agent",
    description: "Book movie tickets and check showtimes",
    icon: Film,
    color: "text-pink-400",
    bgColor: "bg-pink-500/10",
    status: "active",
    capabilities: ["Check showtimes", "Book tickets", "Select seats", "Get recommendations"],
  },
  {
    id: "shopping",
    name: "Shopping Agent",
    description: "Compare prices across multiple sites",
    icon: ShoppingBag,
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
    status: "active",
    capabilities: ["Compare prices", "Find best deals", "Track price history", "Get coupon codes"],
  },
]

export function detectAgent(message: string): AgentType | null {
  const lowered = message.toLowerCase()

  if (
    lowered.includes("travel") ||
    lowered.includes("trip") ||
    lowered.includes("flight") ||
    lowered.includes("route") ||
    lowered.includes("destination") ||
    lowered.includes("vacation")
  ) {
    return "travel"
  }

  if (
    lowered.includes("food") ||
    lowered.includes("restaurant") ||
    lowered.includes("eat") ||
    lowered.includes("hungry") ||
    lowered.includes("dinner") ||
    lowered.includes("lunch") ||
    lowered.includes("breakfast") ||
    lowered.includes("cuisine")
  ) {
    return "food"
  }

  if (
    lowered.includes("cab") ||
    lowered.includes("taxi") ||
    lowered.includes("ride") ||
    lowered.includes("uber") ||
    lowered.includes("pickup") ||
    lowered.includes("drop")
  ) {
    return "cab"
  }

  if (
    lowered.includes("movie") ||
    lowered.includes("film") ||
    lowered.includes("cinema") ||
    lowered.includes("showtime") ||
    lowered.includes("ticket") ||
    lowered.includes("theater")
  ) {
    return "movie"
  }

  if (
    lowered.includes("shop") ||
    lowered.includes("buy") ||
    lowered.includes("price") ||
    lowered.includes("deal") ||
    lowered.includes("compare") ||
    lowered.includes("product") ||
    lowered.includes("purchase")
  ) {
    return "shopping"
  }

  return null
}

export function getAgentById(id: AgentType): Agent | undefined {
  return agents.find((agent) => agent.id === id)
}
