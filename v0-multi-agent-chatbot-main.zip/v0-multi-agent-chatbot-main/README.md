# Multi-agent chatbot

*Automatically synced with your [v0.app](https://v0.app) deployments*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/umesh242006-6209s-projects/v0-multi-agent-chatbot)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.app-black?style=for-the-badge)](https://v0.app/chat/kfkOHQV34ts)

## Overview

This repository will stay in sync with your deployed chats on [v0.app](https://v0.app).
Any changes you make to your deployed app will be automatically pushed to this repository from [v0.app](https://v0.app).

## Deployment

Your project is live at:

**[https://vercel.com/umesh242006-6209s-projects/v0-multi-agent-chatbot](https://vercel.com/umesh242006-6209s-projects/v0-multi-agent-chatbot)**

## Build your app

Continue building your app on:

**[https://v0.app/chat/kfkOHQV34ts](https://v0.app/chat/kfkOHQV34ts)**

## How It Works

1. Create and modify your project using [v0.app](https://v0.app)
2. Deploy your chats from the v0 interface
3. Changes are automatically pushed to this repository
4. Vercel deploys the latest version from this repository