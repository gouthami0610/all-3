import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { Search, Sparkles, TrendingUp, Shield, Users, Briefcase } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const Landing = () => {
  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Matching",
      description: "Get personalized job recommendations based on your skills and preferences"
    },
    {
      icon: Search,
      title: "Smart Search",
      description: "Find opportunities with powerful filters for location, category, and pay"
    },
    {
      icon: TrendingUp,
      title: "Resume Builder",
      description: "Create professional resumes instantly with our AI assistant"
    },
    {
      icon: Shield,
      title: "Verified Employers",
      description: "Work with trusted companies and startups across India"
    }
  ];

  const categories = [
    "Café Staff", "Tutoring", "Babysitting", "IT Intern", 
    "Retail", "Startup Roles", "Content Writing", "Design"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${heroBg})` }}
        />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="font-heading text-5xl md:text-7xl font-bold leading-tight">
              Find Your Perfect
              <span className="block bg-gradient-to-r from-primary via-primary-glow to-secondary bg-clip-text text-transparent mt-2">
                Part-Time Job
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              India's first AI-powered platform connecting students with flexible part-time opportunities. 
              From café jobs to tech internships, your next opportunity awaits.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/auth">
                <Button variant="hero" size="lg" className="w-full sm:w-auto">
                  <Users className="mr-2 h-5 w-5" />
                  Get Started Free
                </Button>
              </Link>
              <Link to="/jobs">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  <Search className="mr-2 h-5 w-5" />
                  Browse Jobs
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { number: "10K+", label: "Active Students" },
              { number: "500+", label: "Verified Employers" },
              { number: "2K+", label: "Jobs Posted" },
              { number: "95%", label: "Success Rate" }
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-4xl font-bold text-primary font-heading">{stat.number}</div>
                <div className="text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold mb-4">Why Choose Roozgar?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Powerful features designed specifically for student job seekers
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => (
              <Card key={i} className="p-6 hover:shadow-lg transition-shadow">
                <feature.icon className="h-12 w-12 text-primary mb-4" />
                <h3 className="font-heading text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-heading text-4xl font-bold mb-4">Popular Job Categories</h2>
            <p className="text-muted-foreground text-lg">Explore opportunities across diverse fields</p>
          </div>
          <div className="flex flex-wrap gap-3 justify-center max-w-4xl mx-auto">
            {categories.map((category, i) => (
              <Link key={i} to="/jobs">
                <Button variant="secondary" size="lg">
                  <Briefcase className="mr-2 h-4 w-4" />
                  {category}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="p-12 text-center bg-gradient-to-r from-primary/10 via-primary-glow/10 to-secondary/10 border-primary/20">
            <h2 className="font-heading text-4xl font-bold mb-4">Ready to Start Your Journey?</h2>
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of students finding meaningful part-time work every day
            </p>
            <Link to="/auth">
              <Button variant="hero" size="lg">
                Sign Up Now - It's Free
              </Button>
            </Link>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2025 Roozgar. Empowering students across India.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;